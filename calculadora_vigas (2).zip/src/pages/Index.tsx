import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

// Tipos de datos
interface Apoyo {
  id: string;
  posicion: number;
  tipo: 'simple' | 'empotrado' | 'rodillo';
  reaccionY?: number;
  reaccionX?: number;
  momento?: number;
}

interface CargaPuntual {
  id: string;
  posicion: number;
  magnitud: number;
}

interface CargaDistribuida {
  id: string;
  inicio: number;
  fin: number;
  intensidad: number;
}

interface Viga {
  longitud: number;
  apoyos: Apoyo[];
  cargasPuntuales: CargaPuntual[];
  cargasDistribuidas: CargaDistribuida[];
}

interface DiagramaData {
  x: number[];
  nx: number[];
  qy: number[];
  mx: number[];
}

// Motor de cálculo estructural
class CalculadoraEstructural {
  static calcularReacciones(viga: Viga): Viga {
    const vigaCalculada = { ...viga };
    const apoyos = [...viga.apoyos].sort((a, b) => a.posicion - b.posicion);
    
    // Calcular cargas totales
    let sumaFuerzas = 0;
    let sumaMomentos = 0;
    
    // Cargas puntuales
    viga.cargasPuntuales.forEach(carga => {
      sumaFuerzas += carga.magnitud;
      sumaMomentos += carga.magnitud * carga.posicion;
    });
    
    // Cargas distribuidas
    viga.cargasDistribuidas.forEach(carga => {
      const longitud = carga.fin - carga.inicio;
      const fuerzaTotal = carga.intensidad * longitud;
      const centroide = carga.inicio + longitud / 2;
      
      sumaFuerzas += fuerzaTotal;
      sumaMomentos += fuerzaTotal * centroide;
    });
    
    // Resolver sistema de ecuaciones para reacciones
    if (apoyos.length === 2) {
      const [apoyo1, apoyo2] = apoyos;
      
      if (apoyo1.tipo === 'empotrado') {
        // Viga empotrada-articulada
        apoyo2.reaccionY = (sumaMomentos - sumaFuerzas * apoyo1.posicion) / (apoyo2.posicion - apoyo1.posicion);
        apoyo1.reaccionY = sumaFuerzas - apoyo2.reaccionY!;
        apoyo1.momento = sumaMomentos - apoyo1.reaccionY * apoyo1.posicion - apoyo2.reaccionY! * apoyo2.posicion;
      } else {
        // Viga simplemente apoyada
        apoyo2.reaccionY = (sumaMomentos - sumaFuerzas * apoyo1.posicion) / (apoyo2.posicion - apoyo1.posicion);
        apoyo1.reaccionY = sumaFuerzas - apoyo2.reaccionY!;
      }
    }
    
    vigaCalculada.apoyos = apoyos;
    return vigaCalculada;
  }
  
  static calcularDiagramas(viga: Viga): DiagramaData {
    const puntos = 100;
    const dx = viga.longitud / (puntos - 1);
    
    const x: number[] = [];
    const nx: number[] = [];
    const qy: number[] = [];
    const mx: number[] = [];
    
    for (let i = 0; i < puntos; i++) {
      const posicion = i * dx;
      x.push(posicion);
      
      // Nx (normalmente 0 para vigas horizontales)
      nx.push(0);
      
      // Calcular Qy y Mx en cada punto
      let cortante = 0;
      let momento = 0;
      
      // Contribución de reacciones
      viga.apoyos.forEach(apoyo => {
        if (apoyo.posicion <= posicion && apoyo.reaccionY) {
          cortante += apoyo.reaccionY;
          momento += apoyo.reaccionY * (posicion - apoyo.posicion);
        }
      });
      
      // Contribución de cargas puntuales
      viga.cargasPuntuales.forEach(carga => {
        if (carga.posicion <= posicion) {
          cortante -= carga.magnitud;
          momento -= carga.magnitud * (posicion - carga.posicion);
        }
      });
      
      // Contribución de cargas distribuidas
      viga.cargasDistribuidas.forEach(carga => {
        if (posicion >= carga.inicio) {
          const finEfectivo = Math.min(posicion, carga.fin);
          const longitud = finEfectivo - carga.inicio;
          const fuerzaAcumulada = carga.intensidad * longitud;
          const centroide = carga.inicio + longitud / 2;
          
          cortante -= fuerzaAcumulada;
          momento -= fuerzaAcumulada * (posicion - centroide);
        }
      });
      
      qy.push(cortante);
      mx.push(momento);
    }
    
    return { x, nx, qy, mx };
  }
}

// Componente de visualización con Canvas
const DiagramaCanvas: React.FC<{ viga: Viga; diagramas: DiagramaData }> = ({ viga, diagramas }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Configurar canvas
    const width = canvas.width;
    const height = canvas.height;
    
    // Limpiar canvas
    ctx.fillStyle = '#1a1a1a';
    ctx.fillRect(0, 0, width, height);
    
    // Configurar escalas con MAYOR SEPARACIÓN entre diagramas
    const margen = 60;
    const escalaX = (width - 2 * margen) / viga.longitud;
    const alturaViga = 40;
    const separacionDiagramas = 140; // 7 párrafos de altura (aprox 20px por párrafo)
    const alturaDiagrama = (height - alturaViga - 6 * margen - 2 * separacionDiagramas) / 3;
    
    // Función para convertir coordenadas
    const toCanvasX = (x: number) => margen + x * escalaX;
    const toCanvasY = (y: number, base: number, escala: number) => base - y * escala;
    
    // Función para dibujar rectángulos con esquinas redondeadas
    const drawRoundedRect = (x: number, y: number, width: number, height: number, radius: number) => {
      ctx.beginPath();
      ctx.moveTo(x + radius, y);
      ctx.lineTo(x + width - radius, y);
      ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
      ctx.lineTo(x + width, y + height - radius);
      ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
      ctx.lineTo(x + radius, y + height);
      ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
      ctx.lineTo(x, y + radius);
      ctx.quadraticCurveTo(x, y, x + radius, y);
      ctx.closePath();
    };
    
    // Dibujar viga
    ctx.strokeStyle = '#00ff00';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(toCanvasX(0), margen + alturaViga / 2);
    ctx.lineTo(toCanvasX(viga.longitud), margen + alturaViga / 2);
    ctx.stroke();
    
    // Dibujar apoyos
    viga.apoyos.forEach(apoyo => {
      const x = toCanvasX(apoyo.posicion);
      const y = margen + alturaViga / 2;
      
      ctx.fillStyle = '#4a90e2';
      ctx.strokeStyle = '#4a90e2';
      ctx.lineWidth = 2;
      
      if (apoyo.tipo === 'empotrado') {
        // Dibujar empotramiento
        ctx.fillRect(x - 5, y - 10, 10, 20);
        ctx.beginPath();
        for (let i = -10; i <= 10; i += 4) {
          ctx.moveTo(x - 5, y + i);
          ctx.lineTo(x - 8, y + i + 2);
        }
        ctx.stroke();
      } else {
        // Dibujar apoyo simple o rodillo
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x - 8, y + 15);
        ctx.lineTo(x + 8, y + 15);
        ctx.closePath();
        ctx.fill();
        
        if (apoyo.tipo === 'rodillo') {
          ctx.beginPath();
          ctx.arc(x, y + 18, 3, 0, 2 * Math.PI);
          ctx.fill();
        }
      }
      
      // Mostrar reacciones
      if (apoyo.reaccionY) {
        ctx.fillStyle = '#ff0000';
        ctx.font = '12px Courier New';
        ctx.fillText(
          `R${apoyo.id} = ${apoyo.reaccionY.toFixed(1)} kg`,
          x - 30,
          y + 35
        );
        
        // Flecha de reacción
        ctx.strokeStyle = '#ff0000';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(x, y + 20);
        ctx.lineTo(x, y + 5);
        ctx.moveTo(x - 3, y + 8);
        ctx.lineTo(x, y + 5);
        ctx.lineTo(x + 3, y + 8);
        ctx.stroke();
      }
    });
    
    // Dibujar cargas puntuales
    viga.cargasPuntuales.forEach(carga => {
      const x = toCanvasX(carga.posicion);
      const y = margen + alturaViga / 2;
      
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x, y - 20);
      ctx.lineTo(x, y);
      ctx.moveTo(x - 3, y - 17);
      ctx.lineTo(x, y - 20);
      ctx.lineTo(x + 3, y - 17);
      ctx.stroke();
      
      ctx.fillStyle = '#ffffff';
      ctx.font = '10px Courier New';
      ctx.fillText(`${carga.magnitud} kg`, x - 20, y - 25);
    });
    
    // Dibujar cargas distribuidas
    viga.cargasDistribuidas.forEach(carga => {
      const x1 = toCanvasX(carga.inicio);
      const x2 = toCanvasX(carga.fin);
      const y = margen + alturaViga / 2;
      
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 1;
      
      // Dibujar flechas distribuidas
      for (let x = x1; x <= x2; x += 15) {
        ctx.beginPath();
        ctx.moveTo(x, y - 15);
        ctx.lineTo(x, y);
        ctx.moveTo(x - 2, y - 12);
        ctx.lineTo(x, y - 15);
        ctx.lineTo(x + 2, y - 12);
        ctx.stroke();
      }
      
      ctx.fillStyle = '#ffffff';
      ctx.font = '10px Courier New';
      ctx.fillText(`${carga.intensidad} kg/m`, (x1 + x2) / 2 - 25, y - 20);
    });
    
    // Calcular escalas para diagramas
    const maxQy = Math.max(...diagramas.qy.map(Math.abs));
    const maxMx = Math.max(...diagramas.mx.map(Math.abs));
    const escalaQy = maxQy > 0 ? alturaDiagrama / (2 * maxQy) : 1;
    const escalaMx = maxMx > 0 ? alturaDiagrama / (2 * maxMx) : 1;
    
    // Dibujar diagrama Qy con líneas verticales rectas (con mayor separación)
    const baseQy = margen + alturaViga + separacionDiagramas + alturaDiagrama / 2;
    ctx.strokeStyle = '#00ffff';
    ctx.fillStyle = 'rgba(0, 255, 255, 0.2)';
    ctx.lineWidth = 2;
    
    // Línea base Qy
    ctx.beginPath();
    ctx.moveTo(toCanvasX(0), baseQy);
    ctx.lineTo(toCanvasX(viga.longitud), baseQy);
    ctx.stroke();
    
    // Diagrama Qy con líneas verticales perfectas
    ctx.beginPath();
    let prevQy = diagramas.qy[0];
    ctx.moveTo(toCanvasX(diagramas.x[0]), toCanvasY(prevQy, baseQy, escalaQy));
    
    for (let i = 1; i < diagramas.x.length; i++) {
      const currentQy = diagramas.qy[i];
      
      // Si hay cambio en el cortante, dibujar línea vertical
      if (Math.abs(currentQy - prevQy) > 0.1) {
        // Línea horizontal hasta el punto de cambio
        ctx.lineTo(toCanvasX(diagramas.x[i]), toCanvasY(prevQy, baseQy, escalaQy));
        // Línea vertical en el cambio
        ctx.lineTo(toCanvasX(diagramas.x[i]), toCanvasY(currentQy, baseQy, escalaQy));
      } else {
        // Línea horizontal normal
        ctx.lineTo(toCanvasX(diagramas.x[i]), toCanvasY(currentQy, baseQy, escalaQy));
      }
      
      prevQy = currentQy;
    }
    ctx.stroke();
    
    // Sombreado Qy
    ctx.beginPath();
    ctx.moveTo(toCanvasX(diagramas.x[0]), baseQy);
    prevQy = diagramas.qy[0];
    ctx.lineTo(toCanvasX(diagramas.x[0]), toCanvasY(prevQy, baseQy, escalaQy));
    
    for (let i = 1; i < diagramas.x.length; i++) {
      const currentQy = diagramas.qy[i];
      
      if (Math.abs(currentQy - prevQy) > 0.1) {
        ctx.lineTo(toCanvasX(diagramas.x[i]), toCanvasY(prevQy, baseQy, escalaQy));
        ctx.lineTo(toCanvasX(diagramas.x[i]), toCanvasY(currentQy, baseQy, escalaQy));
      } else {
        ctx.lineTo(toCanvasX(diagramas.x[i]), toCanvasY(currentQy, baseQy, escalaQy));
      }
      
      prevQy = currentQy;
    }
    ctx.lineTo(toCanvasX(diagramas.x[diagramas.x.length - 1]), baseQy);
    ctx.closePath();
    ctx.fill();
    
    // Agregar valores numéricos SOLO en VÉRTICES (puntos de cambio críticos)
    ctx.textAlign = 'center';
    
    // Detectar SOLO los vértices reales del diagrama Qy
    const verticesQy = new Set<number>();
    
    // Vértices por cargas puntuales (cambios abruptos)
    viga.cargasPuntuales.forEach(carga => {
      verticesQy.add(carga.posicion);
    });
    
    // Vértices por inicio y fin de cargas distribuidas
    viga.cargasDistribuidas.forEach(carga => {
      if (carga.inicio > 0) verticesQy.add(carga.inicio);
      if (carga.fin < viga.longitud) verticesQy.add(carga.fin);
    });
    
    // Vértices por cambios de signo (cruces por cero)
    for (let i = 1; i < diagramas.qy.length - 1; i++) {
      const prevVal = diagramas.qy[i - 1];
      const nextVal = diagramas.qy[i + 1];
      
      // Solo cambios de signo (cruces por cero)
      if ((prevVal > 0 && nextVal < 0) || (prevVal < 0 && nextVal > 0)) {
        verticesQy.add(diagramas.x[i]);
      }
    }
    
    // Vértices en extremos solo si tienen valor significativo
    const valorInicial = diagramas.qy[0];
    const valorFinal = diagramas.qy[diagramas.qy.length - 1];
    if (Math.abs(valorInicial) > 0.1) verticesQy.add(0);
    if (Math.abs(valorFinal) > 0.1) verticesQy.add(viga.longitud);
    
    // Sistema ANTI-SOLAPAMIENTO para valores Qy
    const verticesQyArray = Array.from(verticesQy).sort((a, b) => a - b);
    const posicionesUsadas: Array<{x: number, y: number, ancho: number}> = [];
    
    // Dibujar valores GRANDES solo en VÉRTICES sin solapamiento
    verticesQyArray.forEach(posicion => {
      const x = toCanvasX(posicion);
      const indice = Math.round((posicion / viga.longitud) * (diagramas.x.length - 1));
      const valorQy = diagramas.qy[Math.min(indice, diagramas.qy.length - 1)] || 0;
      
      if (Math.abs(valorQy) > 0.1) {
        let yTexto = valorQy > 0 ? 
          toCanvasY(valorQy, baseQy, escalaQy) - 35 : 
          toCanvasY(valorQy, baseQy, escalaQy) + 50;
        
        // Calcular ancho del texto
        ctx.font = 'bold 18px Courier New';
        const textoAncho = ctx.measureText(`${valorQy.toFixed(0)}`).width * 1.2 + 16;
        
        // Verificar solapamiento y ajustar posición
        let ajustado = false;
        for (let intento = 0; intento < 5; intento++) {
          let solapa = false;
          
          for (const usado of posicionesUsadas) {
            const distanciaX = Math.abs(x - usado.x);
            const distanciaY = Math.abs(yTexto - usado.y);
            
            // Si está muy cerca horizontalmente y verticalmente
            if (distanciaX < (textoAncho + usado.ancho) / 2 + 10 && distanciaY < 35) {
              solapa = true;
              break;
            }
          }
          
          if (!solapa) {
            ajustado = true;
            break;
          }
          
          // Ajustar posición: alternar arriba/abajo
          if (valorQy > 0) {
            yTexto -= 40; // Mover más arriba
          } else {
            yTexto += 40; // Mover más abajo
          }
        }
        
        // Registrar posición usada
        posicionesUsadas.push({x, y: yTexto, ancho: textoAncho});
        
        // Fondo negro semi-transparente con ESQUINAS REDONDEADAS (sin solapamiento)
        ctx.fillStyle = 'rgba(0, 0, 0, 0.9)';
        drawRoundedRect(x - textoAncho/2, yTexto - 20, textoAncho, 28, 8);
        ctx.fill();
        
        // Borde redondeado para destacar más
        ctx.strokeStyle = '#00ffff';
        ctx.lineWidth = 2;
        drawRoundedRect(x - textoAncho/2, yTexto - 20, textoAncho, 28, 8);
        ctx.stroke();
        
        // Texto GRANDE y BOLD
        ctx.fillStyle = '#00ffff';
        ctx.font = 'bold 18px Courier New';
        ctx.fillText(`${valorQy.toFixed(0)}`, x, yTexto);
        
        // Línea de referencia más visible
        ctx.strokeStyle = 'rgba(0, 255, 255, 0.8)';
        ctx.lineWidth = 2;
        ctx.setLineDash([6, 6]);
        ctx.beginPath();
        ctx.moveTo(x, toCanvasY(valorQy, baseQy, escalaQy));
        ctx.lineTo(x, yTexto + 12);
        ctx.stroke();
        ctx.setLineDash([]);
        
        // Círculo marcador MÁS GRANDE
        ctx.beginPath();
        ctx.arc(x, toCanvasY(valorQy, baseQy, escalaQy), 6, 0, 2 * Math.PI);
        ctx.fillStyle = '#00ffff';
        ctx.fill();
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 2;
        ctx.stroke();
        
      } else if (Math.abs(valorQy) <= 0.1) {
        // Marcar ceros con estilo GRANDE y esquinas redondeadas
        ctx.fillStyle = 'rgba(0, 0, 0, 0.9)';
        drawRoundedRect(x - 20, baseQy - 30, 40, 28, 8);
        ctx.fill();
        ctx.strokeStyle = '#00ffff';
        ctx.lineWidth = 2;
        drawRoundedRect(x - 20, baseQy - 30, 40, 28, 8);
        ctx.stroke();
        
        ctx.fillStyle = '#00ffff';
        ctx.font = 'bold 18px Courier New';
        ctx.fillText('0', x, baseQy - 8);
        
        // Círculo marcador para cero
        ctx.beginPath();
        ctx.arc(x, baseQy, 6, 0, 2 * Math.PI);
        ctx.fillStyle = '#00ffff';
        ctx.fill();
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    });
    
    // Etiqueta Qy MÁS GRANDE
    ctx.fillStyle = '#00ffff';
    ctx.font = 'bold 20px Courier New';
    ctx.textAlign = 'left';
    ctx.fillText('Qy (kg)', 10, baseQy - alturaDiagrama / 2 - 10);
    
    // Dibujar diagrama Mx INVERTIDO (negativo arriba) con mayor separación
    const baseMx = baseQy + separacionDiagramas + alturaDiagrama / 2;
    ctx.strokeStyle = '#ffff00';
    ctx.fillStyle = 'rgba(255, 255, 0, 0.2)';
    
    // Línea base Mx
    ctx.beginPath();
    ctx.moveTo(toCanvasX(0), baseMx);
    ctx.lineTo(toCanvasX(viga.longitud), baseMx);
    ctx.stroke();
    
    // Diagrama Mx INVERTIDO (multiplicar por -1 para invertir)
    ctx.beginPath();
    ctx.moveTo(toCanvasX(diagramas.x[0]), toCanvasY(-diagramas.mx[0], baseMx, escalaMx));
    for (let i = 1; i < diagramas.x.length; i++) {
      ctx.lineTo(toCanvasX(diagramas.x[i]), toCanvasY(-diagramas.mx[i], baseMx, escalaMx));
    }
    ctx.stroke();
    
    // Sombreado Mx INVERTIDO
    ctx.beginPath();
    ctx.moveTo(toCanvasX(diagramas.x[0]), baseMx);
    for (let i = 0; i < diagramas.x.length; i++) {
      ctx.lineTo(toCanvasX(diagramas.x[i]), toCanvasY(-diagramas.mx[i], baseMx, escalaMx));
    }
    ctx.lineTo(toCanvasX(diagramas.x[diagramas.x.length - 1]), baseMx);
    ctx.closePath();
    ctx.fill();
    
    // Agregar valores numéricos SOLO en VÉRTICES del diagrama Mx
    ctx.textAlign = 'center';
    
    // Detectar SOLO los vértices reales del diagrama Mx
    const verticesMx = new Set<number>();
    
    // Vértices por cargas puntuales (puntos de inflexión)
    viga.cargasPuntuales.forEach(carga => {
      verticesMx.add(carga.posicion);
    });
    
    // Vértices por extremos locales (máximos y mínimos reales)
    for (let i = 2; i < diagramas.mx.length - 2; i++) {
      const prevVal = diagramas.mx[i - 1];
      const currentVal = diagramas.mx[i];
      const nextVal = diagramas.mx[i + 1];
      
      // Solo extremos locales significativos (máximos y mínimos)
      if ((currentVal > prevVal && currentVal > nextVal && Math.abs(currentVal) > 100) || 
          (currentVal < prevVal && currentVal < nextVal && Math.abs(currentVal) > 100)) {
        verticesMx.add(diagramas.x[i]);
      }
    }
    
    // Vértices por cambios de signo (cruces por cero)
    for (let i = 1; i < diagramas.mx.length - 1; i++) {
      const prevVal = diagramas.mx[i - 1];
      const nextVal = diagramas.mx[i + 1];
      
      // Solo cambios de signo
      if ((prevVal > 0 && nextVal < 0) || (prevVal < 0 && nextVal > 0)) {
        verticesMx.add(diagramas.x[i]);
      }
    }
    
    // Vértices en extremos solo si tienen valor significativo
    const valorInicialMx = diagramas.mx[0];
    const valorFinalMx = diagramas.mx[diagramas.mx.length - 1];
    if (Math.abs(valorInicialMx) > 0.1) verticesMx.add(0);
    if (Math.abs(valorFinalMx) > 0.1) verticesMx.add(viga.longitud);
    
    // Sistema ANTI-SOLAPAMIENTO para valores Mx
    const verticesMxArray = Array.from(verticesMx).sort((a, b) => a - b);
    const posicionesUsadasMx: Array<{x: number, y: number, ancho: number}> = [];
    
    // Dibujar valores GRANDES solo en VÉRTICES sin solapamiento
    verticesMxArray.forEach(posicion => {
      const x = toCanvasX(posicion);
      const indice = Math.round((posicion / viga.longitud) * (diagramas.x.length - 1));
      const valorMx = diagramas.mx[Math.min(indice, diagramas.mx.length - 1)] || 0;
      
      if (Math.abs(valorMx) > 0.1) {
        // Recordar que invertimos el diagrama, así que usamos -valorMx para la posición Y
        let yTexto = valorMx < 0 ? 
          toCanvasY(-valorMx, baseMx, escalaMx) - 35 :
          toCanvasY(-valorMx, baseMx, escalaMx) + 50;
        
        // Calcular ancho del texto
        ctx.font = 'bold 18px Courier New';
        const textoAnchoMx = ctx.measureText(`${valorMx.toFixed(0)}`).width * 1.2 + 16;
        
        // Verificar solapamiento y ajustar posición
        for (let intento = 0; intento < 5; intento++) {
          let solapa = false;
          
          for (const usado of posicionesUsadasMx) {
            const distanciaX = Math.abs(x - usado.x);
            const distanciaY = Math.abs(yTexto - usado.y);
            
            // Si está muy cerca horizontalmente y verticalmente
            if (distanciaX < (textoAnchoMx + usado.ancho) / 2 + 10 && distanciaY < 35) {
              solapa = true;
              break;
            }
          }
          
          if (!solapa) {
            break;
          }
          
          // Ajustar posición: alternar arriba/abajo
          if (valorMx < 0) {
            yTexto -= 40; // Mover más arriba (valores negativos)
          } else {
            yTexto += 40; // Mover más abajo (valores positivos)
          }
        }
        
        // Registrar posición usada
        posicionesUsadasMx.push({x, y: yTexto, ancho: textoAnchoMx});
        
        // Fondo negro semi-transparente con ESQUINAS REDONDEADAS (sin solapamiento)
        ctx.fillStyle = 'rgba(0, 0, 0, 0.9)';
        drawRoundedRect(x - textoAnchoMx/2, yTexto - 20, textoAnchoMx, 28, 8);
        ctx.fill();
        
        // Borde redondeado para destacar más
        ctx.strokeStyle = '#ffff00';
        ctx.lineWidth = 2;
        drawRoundedRect(x - textoAnchoMx/2, yTexto - 20, textoAnchoMx, 28, 8);
        ctx.stroke();
        
        // Texto GRANDE y BOLD
        ctx.fillStyle = '#ffff00';
        ctx.font = 'bold 18px Courier New';
        ctx.fillText(`${valorMx.toFixed(0)}`, x, yTexto);
        
        // Línea de referencia más visible
        ctx.strokeStyle = 'rgba(255, 255, 0, 0.8)';
        ctx.lineWidth = 2;
        ctx.setLineDash([6, 6]);
        ctx.beginPath();
        ctx.moveTo(x, toCanvasY(-valorMx, baseMx, escalaMx));
        ctx.lineTo(x, yTexto + 12);
        ctx.stroke();
        ctx.setLineDash([]);
        
        // Marcar extremos con círculos MÁS GRANDES
        const esExtremo = Math.abs(valorMx) === Math.max(...diagramas.mx.map(Math.abs));
        if (esExtremo) {
          ctx.beginPath();
          ctx.arc(x, toCanvasY(-valorMx, baseMx, escalaMx), 8, 0, 2 * Math.PI);
          ctx.fillStyle = '#ffff00';
          ctx.fill();
          ctx.strokeStyle = '#000000';
          ctx.lineWidth = 3;
          ctx.stroke();
          
          // Etiqueta MAX/MIN GRANDE con esquinas redondeadas
          ctx.fillStyle = 'rgba(0, 0, 0, 0.95)';
          const etiqueta = valorMx > 0 ? 'MAX' : 'MIN';
          const etiquetaAncho = ctx.measureText(etiqueta).width;
          drawRoundedRect(x - etiquetaAncho/2 - 6, yTexto - 45, etiquetaAncho + 12, 20, 6);
          ctx.fill();
          ctx.strokeStyle = '#ffff00';
          ctx.lineWidth = 2;
          drawRoundedRect(x - etiquetaAncho/2 - 6, yTexto - 45, etiquetaAncho + 12, 20, 6);
          ctx.stroke();
          ctx.fillStyle = '#ffff00';
          ctx.font = 'bold 16px Courier New';
          ctx.fillText(etiqueta, x, yTexto - 30);
        } else {
          // Círculo normal MÁS GRANDE para otros puntos importantes
          ctx.beginPath();
          ctx.arc(x, toCanvasY(-valorMx, baseMx, escalaMx), 6, 0, 2 * Math.PI);
          ctx.fillStyle = '#ffff00';
          ctx.fill();
          ctx.strokeStyle = '#000000';
          ctx.lineWidth = 2;
          ctx.stroke();
        }
      } else if (Math.abs(valorMx) <= 0.1) {
        // Marcar ceros con estilo GRANDE y esquinas redondeadas
        ctx.fillStyle = 'rgba(0, 0, 0, 0.9)';
        drawRoundedRect(x - 20, baseMx - 30, 40, 28, 8);
        ctx.fill();
        ctx.strokeStyle = '#ffff00';
        ctx.lineWidth = 2;
        drawRoundedRect(x - 20, baseMx - 30, 40, 28, 8);
        ctx.stroke();
        
        ctx.fillStyle = '#ffff00';
        ctx.font = 'bold 18px Courier New';
        ctx.fillText('0', x, baseMx - 8);
        
        // Círculo marcador para cero
        ctx.beginPath();
        ctx.arc(x, baseMx, 6, 0, 2 * Math.PI);
        ctx.fillStyle = '#ffff00';
        ctx.fill();
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    });
    
    // Etiqueta Mx MÁS GRANDE
    ctx.fillStyle = '#ffff00';
    ctx.font = 'bold 20px Courier New';
    ctx.textAlign = 'left';
    ctx.fillText('Mx (kg·m)', 10, baseMx - alturaDiagrama / 2 - 10);
  }, [viga, diagramas]);
  
  return (
    <canvas
      ref={canvasRef}
      width={1000}
      height={880}
      className="diagram-canvas w-full max-w-full"
      style={{ maxHeight: '880px' }}
    />
  );
};

// Componente principal
const CalculadoraVigas: React.FC = () => {
  const [viga, setViga] = useState<Viga>({
    longitud: 10.4,
    apoyos: [
      { id: 'A', posicion: 1.9, tipo: 'empotrado' },
      { id: 'B', posicion: 10.4, tipo: 'simple' }
    ],
    cargasPuntuales: [
      { id: '1', posicion: 4.1, magnitud: 15974 }
    ],
    cargasDistribuidas: [
      { id: '1', inicio: 0, fin: 10.4, intensidad: 2156 }
    ]
  });
  
  const [vigaCalculada, setVigaCalculada] = useState<Viga>(viga);
  const [diagramas, setDiagramas] = useState<DiagramaData>({ x: [], nx: [], qy: [], mx: [] });
  
  // Calcular diagramas cuando cambie la viga
  useEffect(() => {
    const calculada = CalculadoraEstructural.calcularReacciones(viga);
    const diagramasCalculados = CalculadoraEstructural.calcularDiagramas(calculada);
    
    setVigaCalculada(calculada);
    setDiagramas(diagramasCalculados);
  }, [viga]);
  
  // Funciones para manejar cambios
  const actualizarLongitud = (longitud: number) => {
    setViga(prev => ({ ...prev, longitud }));
  };
  
  const agregarApoyo = () => {
    if (viga.apoyos.length >= 5) {
      toast.error('Máximo 5 apoyos permitidos');
      return;
    }
    
    const nuevoApoyo: Apoyo = {
      id: String.fromCharCode(65 + viga.apoyos.length),
      posicion: viga.longitud / 2,
      tipo: 'simple'
    };
    
    setViga(prev => ({
      ...prev,
      apoyos: [...prev.apoyos, nuevoApoyo]
    }));
  };
  
  const actualizarApoyo = (id: string, cambios: Partial<Apoyo>) => {
    setViga(prev => ({
      ...prev,
      apoyos: prev.apoyos.map(apoyo =>
        apoyo.id === id ? { ...apoyo, ...cambios } : apoyo
      )
    }));
  };
  
  const eliminarApoyo = (id: string) => {
    setViga(prev => ({
      ...prev,
      apoyos: prev.apoyos.filter(apoyo => apoyo.id !== id)
    }));
  };
  
  const agregarCargaPuntual = () => {
    if (viga.cargasPuntuales.length >= 10) {
      toast.error('Máximo 10 cargas puntuales permitidas');
      return;
    }
    
    const nuevaCarga: CargaPuntual = {
      id: String(viga.cargasPuntuales.length + 1),
      posicion: viga.longitud / 2,
      magnitud: 1000
    };
    
    setViga(prev => ({
      ...prev,
      cargasPuntuales: [...prev.cargasPuntuales, nuevaCarga]
    }));
  };
  
  const actualizarCargaPuntual = (id: string, cambios: Partial<CargaPuntual>) => {
    setViga(prev => ({
      ...prev,
      cargasPuntuales: prev.cargasPuntuales.map(carga =>
        carga.id === id ? { ...carga, ...cambios } : carga
      )
    }));
  };
  
  const eliminarCargaPuntual = (id: string) => {
    setViga(prev => ({
      ...prev,
      cargasPuntuales: prev.cargasPuntuales.filter(carga => carga.id !== id)
    }));
  };
  
  const agregarCargaDistribuida = () => {
    if (viga.cargasDistribuidas.length >= 5) {
      toast.error('Máximo 5 cargas distribuidas permitidas');
      return;
    }
    
    const nuevaCarga: CargaDistribuida = {
      id: String(viga.cargasDistribuidas.length + 1),
      inicio: 0,
      fin: viga.longitud,
      intensidad: 1000
    };
    
    setViga(prev => ({
      ...prev,
      cargasDistribuidas: [...prev.cargasDistribuidas, nuevaCarga]
    }));
  };
  
  const actualizarCargaDistribuida = (id: string, cambios: Partial<CargaDistribuida>) => {
    setViga(prev => ({
      ...prev,
      cargasDistribuidas: prev.cargasDistribuidas.map(carga =>
        carga.id === id ? { ...carga, ...cambios } : carga
      )
    }));
  };
  
  const eliminarCargaDistribuida = (id: string) => {
    setViga(prev => ({
      ...prev,
      cargasDistribuidas: prev.cargasDistribuidas.filter(carga => carga.id !== id)
    }));
  };
  
  const cargarEjemplo = () => {
    setViga({
      longitud: 10.4,
      apoyos: [
        { id: 'A', posicion: 1.9, tipo: 'empotrado' },
        { id: 'B', posicion: 10.4, tipo: 'simple' }
      ],
      cargasPuntuales: [
        { id: '1', posicion: 4.1, magnitud: 15974 }
      ],
      cargasDistribuidas: [
        { id: '1', inicio: 0, fin: 10.4, intensidad: 2156 }
      ]
    });
    toast.success('Ejemplo cargado correctamente');
  };
  
  const exportarImagen = () => {
    const canvas = document.querySelector('canvas');
    if (canvas) {
      const link = document.createElement('a');
      link.download = 'diagrama_viga.png';
      link.href = canvas.toDataURL();
      link.click();
      toast.success('Imagen exportada correctamente');
    }
  };
  
  const guardarProyecto = () => {
    const proyecto = {
      nombre: `Viga_${new Date().toISOString().slice(0, 10)}`,
      fecha: new Date().toISOString(),
      viga: viga
    };
    
    const blob = new Blob([JSON.stringify(proyecto, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${proyecto.nombre}.json`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success('Proyecto guardado correctamente');
  };
  
  const cargarProyecto = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const proyecto = JSON.parse(e.target?.result as string);
          setViga(proyecto.viga);
          toast.success('Proyecto cargado correctamente');
        } catch (error) {
          toast.error('Error al cargar el proyecto');
        }
      };
      reader.readAsText(file);
    }
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black p-4 tech-grid">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold neon-text tracking-wider">
            CALCULADORA DE VIGAS
          </h1>
          <p className="cyan-text text-lg">
            Sistema de Análisis Estructural - Diagramas de Esfuerzos
          </p>
          <div className="flex justify-center gap-4 mt-4">
            <Button onClick={cargarEjemplo} className="tech-button">
              Cargar Ejemplo
            </Button>
            <Button onClick={guardarProyecto} className="tech-button">
              Guardar Proyecto
            </Button>
            <label className="tech-button cursor-pointer inline-flex items-center justify-center px-4 py-2 rounded">
              Cargar Proyecto
              <input
                type="file"
                accept=".json"
                onChange={cargarProyecto}
                className="hidden"
              />
            </label>
            <Button onClick={exportarImagen} className="tech-button">
              Exportar Imagen
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Panel de entrada de datos */}
          <div className="lg:col-span-1 space-y-4">
            <Card className="tech-border bg-card/50">
              <CardHeader>
                <CardTitle className="neon-text">Configuración de Viga</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="cyan-text">Longitud Total (m)</Label>
                  <Input
                    type="number"
                    value={viga.longitud}
                    onChange={(e) => actualizarLongitud(Number(e.target.value))}
                    className="tech-input"
                    step="0.1"
                    min="0.1"
                  />
                </div>
              </CardContent>
            </Card>
            
            <Tabs defaultValue="apoyos" className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-muted/50">
                <TabsTrigger value="apoyos" className="text-xs">Apoyos</TabsTrigger>
                <TabsTrigger value="puntuales" className="text-xs">C. Puntuales</TabsTrigger>
                <TabsTrigger value="distribuidas" className="text-xs">C. Distribuidas</TabsTrigger>
              </TabsList>
              
              <TabsContent value="apoyos" className="space-y-2">
                <Card className="tech-border bg-card/50">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-sm neon-text">Apoyos</CardTitle>
                      <Button onClick={agregarApoyo} size="sm" className="tech-button text-xs">
                        + Agregar
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {viga.apoyos.map((apoyo) => (
                      <div key={apoyo.id} className="p-3 border border-primary/20 rounded space-y-2">
                        <div className="flex justify-between items-center">
                          <Badge variant="outline" className="neon-text">
                            Apoyo {apoyo.id}
                          </Badge>
                          <Button
                            onClick={() => eliminarApoyo(apoyo.id)}
                            size="sm"
                            variant="destructive"
                            className="text-xs"
                          >
                            ×
                          </Button>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <Label className="text-xs cyan-text">Posición (m)</Label>
                            <Input
                              type="number"
                              value={apoyo.posicion}
                              onChange={(e) => actualizarApoyo(apoyo.id, { posicion: Number(e.target.value) })}
                              className="tech-input text-xs"
                              step="0.1"
                              min="0"
                              max={viga.longitud}
                            />
                          </div>
                          <div>
                            <Label className="text-xs cyan-text">Tipo</Label>
                            <Select
                              value={apoyo.tipo}
                              onValueChange={(value: 'simple' | 'empotrado' | 'rodillo') =>
                                actualizarApoyo(apoyo.id, { tipo: value })
                              }
                            >
                              <SelectTrigger className="tech-input text-xs">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="simple">Simple</SelectItem>
                                <SelectItem value="empotrado">Empotrado</SelectItem>
                                <SelectItem value="rodillo">Rodillo</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        {vigaCalculada.apoyos.find(a => a.id === apoyo.id)?.reaccionY && (
                          <div className="text-xs warning-text">
                            Reacción: {vigaCalculada.apoyos.find(a => a.id === apoyo.id)?.reaccionY?.toFixed(1)} kg
                          </div>
                        )}
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="puntuales" className="space-y-2">
                <Card className="tech-border bg-card/50">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-sm neon-text">Cargas Puntuales</CardTitle>
                      <Button onClick={agregarCargaPuntual} size="sm" className="tech-button text-xs">
                        + Agregar
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {viga.cargasPuntuales.map((carga) => (
                      <div key={carga.id} className="p-3 border border-primary/20 rounded space-y-2">
                        <div className="flex justify-between items-center">
                          <Badge variant="outline" className="neon-text">
                            Carga {carga.id}
                          </Badge>
                          <Button
                            onClick={() => eliminarCargaPuntual(carga.id)}
                            size="sm"
                            variant="destructive"
                            className="text-xs"
                          >
                            ×
                          </Button>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <Label className="text-xs cyan-text">Posición (m)</Label>
                            <Input
                              type="number"
                              value={carga.posicion}
                              onChange={(e) => actualizarCargaPuntual(carga.id, { posicion: Number(e.target.value) })}
                              className="tech-input text-xs"
                              step="0.1"
                              min="0"
                              max={viga.longitud}
                            />
                          </div>
                          <div>
                            <Label className="text-xs cyan-text">Magnitud (kg)</Label>
                            <Input
                              type="number"
                              value={carga.magnitud}
                              onChange={(e) => actualizarCargaPuntual(carga.id, { magnitud: Number(e.target.value) })}
                              className="tech-input text-xs"
                              step="100"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="distribuidas" className="space-y-2">
                <Card className="tech-border bg-card/50">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-sm neon-text">Cargas Distribuidas</CardTitle>
                      <Button onClick={agregarCargaDistribuida} size="sm" className="tech-button text-xs">
                        + Agregar
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {viga.cargasDistribuidas.map((carga) => (
                      <div key={carga.id} className="p-3 border border-primary/20 rounded space-y-2">
                        <div className="flex justify-between items-center">
                          <Badge variant="outline" className="neon-text">
                            Carga Dist. {carga.id}
                          </Badge>
                          <Button
                            onClick={() => eliminarCargaDistribuida(carga.id)}
                            size="sm"
                            variant="destructive"
                            className="text-xs"
                          >
                            ×
                          </Button>
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <div>
                            <Label className="text-xs cyan-text">Inicio (m)</Label>
                            <Input
                              type="number"
                              value={carga.inicio}
                              onChange={(e) => actualizarCargaDistribuida(carga.id, { inicio: Number(e.target.value) })}
                              className="tech-input text-xs"
                              step="0.1"
                              min="0"
                              max={viga.longitud}
                            />
                          </div>
                          <div>
                            <Label className="text-xs cyan-text">Fin (m)</Label>
                            <Input
                              type="number"
                              value={carga.fin}
                              onChange={(e) => actualizarCargaDistribuida(carga.id, { fin: Number(e.target.value) })}
                              className="tech-input text-xs"
                              step="0.1"
                              min="0"
                              max={viga.longitud}
                            />
                          </div>
                          <div>
                            <Label className="text-xs cyan-text">Intensidad (kg/m)</Label>
                            <Input
                              type="number"
                              value={carga.intensidad}
                              onChange={(e) => actualizarCargaDistribuida(carga.id, { intensidad: Number(e.target.value) })}
                              className="tech-input text-xs"
                              step="100"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          {/* Panel de visualización */}
          <div className="lg:col-span-2">
            <Card className="tech-border bg-card/50">
              <CardHeader>
                <CardTitle className="neon-text">Diagramas de Esfuerzos</CardTitle>
                <p className="text-sm cyan-text">
                  Longitud: {viga.longitud}m | Apoyos: {viga.apoyos.length} | 
                  Cargas P: {viga.cargasPuntuales.length} | Cargas D: {viga.cargasDistribuidas.length}
                </p>
              </CardHeader>
              <CardContent>
                <div className="w-full overflow-auto">
                  <DiagramaCanvas viga={vigaCalculada} diagramas={diagramas} />
                </div>
                
                {/* Resultados numéricos */}
                <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold neon-text mb-2">Reacciones en Apoyos</h4>
                    <div className="space-y-1 text-sm">
                      {vigaCalculada.apoyos.map(apoyo => (
                        <div key={apoyo.id} className="flex justify-between">
                          <span className="cyan-text">R{apoyo.id}:</span>
                          <span className="steel-text">
                            {apoyo.reaccionY?.toFixed(1) || '0.0'} kg
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold neon-text mb-2">Valores Extremos</h4>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span className="cyan-text">Qy máx:</span>
                        <span className="steel-text">
                          {Math.max(...diagramas.qy).toFixed(1)} kg
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="cyan-text">Qy mín:</span>
                        <span className="steel-text">
                          {Math.min(...diagramas.qy).toFixed(1)} kg
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="cyan-text">Mx máx:</span>
                        <span className="steel-text">
                          {Math.max(...diagramas.mx).toFixed(1)} kg·m
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="cyan-text">Mx mín:</span>
                        <span className="steel-text">
                          {Math.min(...diagramas.mx).toFixed(1)} kg·m
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CalculadoraVigas;